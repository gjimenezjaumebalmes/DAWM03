import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Spliterator;
import java.util.function.Consumer;

public abstract class Cadena implements Cadenable, Iterable<Character> {
    private static char[] cad;
    private static int len;

    public Cadena() {
        cad = new char[0];
        len = 0;
    }

    public Cadena(String s) {
        len = s.length();
        cad = new char[len];
        for (int i = 0; i < len; i++) {
            cad[i] = s.charAt(i);
        }
    }

    public Cadena(char[] s) {
        len = s.length;
        cad = new char[len];
        System.arraycopy(s, 0, cad, 0, len);
    }

    public Cadena(Cadena s) {
        len = s.len;
        cad = new char[len];
        System.arraycopy(s.cad, 0, cad, 0, len);
    }

    public static Cadena concat(Cadena sx, String s) {
        Cadena result = new Cadena(sx) {
            @Override
            public void forEach(Consumer<? super Character> action) {
                super.forEach(action);
            }

            @Override
            public Spliterator<Character> spliterator() {
                return super.spliterator();
            }

            @Override
            public void insert(char c, int n) {

            }

            @Override
            public void delete(int n) {

            }

            @Override
            public void deleteAll(char c) {

            }
        };
        result.concat(s);
        return result;
    }

    public static boolean equals(Cadena s, Cadena sx) {
        return s.equals(sx);
    }

    public Cadena clona() {
        return new Cadena(this) {
            @Override
            public void forEach(Consumer<? super Character> action) {
                super.forEach(action);
            }

            @Override
            public Spliterator<Character> spliterator() {
                return super.spliterator();
            }

            @Override
            public void insert(char c, int n) {

            }

            @Override
            public void delete(int n) {

            }

            @Override
            public void deleteAll(char c) {

            }
        };
    }

    public boolean equals(Cadena s) {
        if (len != s.len) {
            return false;
        }
        for (int i = 0; i < len; i++) {
            if (cad[i] != s.cad[i]) {
                return false;
            }
        }
        return true;
    }

    public void concat(Cadena s) {
        int newLen = len + s.len;
        char[] newCad = new char[newLen];
        System.arraycopy(cad, 0, newCad, 0, len);
        System.arraycopy(s.cad, 0, newCad, len, s.len);
        cad = newCad;
        len = newLen;
    }

    public void concat(String s) {
        concat(new Cadena(s) {
            @Override
            public void forEach(Consumer<? super Character> action) {
                super.forEach(action);
            }

            @Override
            public Spliterator<Character> spliterator() {
                return super.spliterator();
            }

            @Override
            public void insert(char c, int n) {

            }

            @Override
            public void delete(int n) {

            }

            @Override
            public void deleteAll(char c) {

            }
        });
    }

    public void concat(char c) {
        concat(new Cadena(new char[]{c}) {
            @Override
            public void forEach(Consumer<? super Character> action) {
                super.forEach(action);
            }

            @Override
            public Spliterator<Character> spliterator() {
                return super.spliterator();
            }

            @Override
            public void insert(char c, int n) {

            }

            @Override
            public void delete(int n) {

            }

            @Override
            public void deleteAll(char c) {

            }
        });
    }

    public static void insert(Cadena sx, char c, int n) {
        if (n < 0 || n > len) {
            return;
        }
        char[] newCad = new char[len + 1];
        System.arraycopy(cad, 0, newCad, 0, n);
        newCad[n] = c;
        System.arraycopy(cad, n, newCad, n + 1, len - n);
        cad = newCad;
        len++;
    }

    public static void delete(Cadena sx, int n) {
        if (n < 0 || n >= len) {
            return;
        }
        char[] newCad = new char[len - 1];
        System.arraycopy(cad, 0, newCad, 0, n);
        System.arraycopy(cad, n + 1, newCad, n, len - n - 1);
        cad = newCad;
        len--;
    }

    public static Cadena deleteAll(Cadena sx, char c) {
        int count = 0;
        for (int i = 0; i < len; i++) {
            if (cad[i] == c) {
                count++;
            }
        }
        char[] newCad = new char[len - count];
        int j = 0;
        for (int i = 0; i < len; i++) {
            if (cad[i] != c) {
                newCad[j] = cad[i];
                j++;
            }
        }
        cad = newCad;
        len -= count;
        return sx;
    }


    public void permuta(int x, int y) {
        if (x < 0 || x >= len || y < 0 || y >= len) {
            return;
        }
        char temp = cad[x];
        cad[x] = cad[y];
        cad[y] = temp;
    }

    @Override
    public void clear() {
        cad = new char[0];
        len = 0;
    }


    @Override
    public Iterator<Character> iterator() {
        return new CadenaIterator();
    }

    private class CadenaIterator implements Iterator<Character> {
        private int currentIndex = 0;

        @Override
        public boolean hasNext() {
            return currentIndex < len;
        }

        @Override
        public Character next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            char currentChar = cad[currentIndex];
            currentIndex++;
            return currentChar;
        }

    }
}