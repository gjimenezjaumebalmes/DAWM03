import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Spliterator;
import java.util.function.Consumer;

public abstract class Cadena implements Cadenable, Iterable<Character> {

    // Una matriu estàtica "cad" per emmagatzemar caràcters i un enter "len" per emmagatzemar la longitud de la cadena.
    private static char[] cad;
    private static int len;

    // Constructor que pren una cadena com a argument.
    public Cadena() {
        // Inicialitza la matriu de caràcters amb els caràcters de la cadena i estableix la longitud corresponent.        cad = new char[0];
        len = 0;
    }

    // Constructor que pren una matriu de caràcters com a argument.
    public Cadena(String s) {
       // Inicialitza la matriu de caràcters amb els caràcters de la cadena i estableix la longitud corresponent.
        len = s.length();
        cad = new char[len];
        for (int i = 0; i < len; i++) {
            cad[i] = s.charAt(i);
        }
    }

    public Cadena(char[] s) {
        // Inicializa la matriz de caracteres con los caracteres de la matriz y establece la longitud correspondiente.
        len = s.length;
        cad = new char[len];
        System.arraycopy(s, 0, cad, 0, len);
    }

    // Constructor que toma un objeto Cadena como argumento.
    public Cadena(Cadena s) {
        len = s.len;
        cad = new char[len];
        System.arraycopy(s.cad, 0, cad, 0, len);
    }

    // Mètode de classe que concatena una cadena i una cadena donada.
    public static Cadena concat(Cadena sx, String s) {
        // Crea un objecte Cadena amb la cadena existent.
        Cadena result = new Cadena(sx) {
            public void forEach(Consumer<? super Character> action) {
                super.forEach(action);
            }

            public Spliterator<Character> spliterator() {
                return super.spliterator();
            }

            public void insert(char c, int n) {

            }

            public void delete(int n) {

            }

            public void deleteAll(char c) {

            }
        };
    // Concatena la cadena donada amb l'objecte Cadena creat anteriorment.
        result.concat(s);
    // Retorna l'objecte Cadena concatenat.
        return result;
    }

    // Mètode de classe que compara dos objectes Cadena i retorna cert si són iguals, sinó, fals.
    public static boolean equals(Cadena s, Cadena sx) {
        return s.equals(sx);
    }

    // Mètode que retorna una còpia de l'objecte Cadena actual.
    public Cadena clona() { // clona la cadena
        return new Cadena(this) { // s'utilitza una classe anònima per evitar modificacions no desitjades

            public void forEach(Consumer<? super Character> action) {
                super.forEach(action);
            }

            public Spliterator<Character> spliterator() {
                return super.spliterator();
            }

            public void insert(char c, int n) {

            }

            public void delete(int n) {

            }

            public void deleteAll(char c) {

            }
        };
    }

    public boolean equals(Cadena s) { // compara la cadena amb una altra cadena
        if (len != s.len) {
            return false;
        }
        for (int i = 0; i < len; i++) {
            if (cad[i] != s.cad[i]) {
                return false;
            }
        }
        return true;
    }

    public void concat(Cadena s) {
        int newLen = len + s.len; // calcula la longitud de la nova cadena
        char[] newCad = new char[newLen]; // crea un nou array de caràcters amb la longitud calculada
        System.arraycopy(cad, 0, newCad, 0, len); // copia els caràcters de l'array actual al nou array
        System.arraycopy(s.cad, 0, newCad, len, s.len); // copia els caràcters de l'altre cadena al nou array
        cad = newCad; // actualitza l'array actual amb el nou array
        len = newLen; // actualitza la longitud de l'array actual amb la longitud de la nova cadena
    }

    public void concat(String s) {
        concat(new Cadena(s) { // crea una nova cadena de tipus Cadena i crida la funció concat anterior amb la nova cadena com a argument

            public void forEach(Consumer<? super Character> action) { // sobreescriu el mètode forEach de la classe Cadena
                super.forEach(action); // crida el mètode forEach de la superclasse Cadena
            }

            public Spliterator<Character> spliterator() { // sobreescriu el mètode spliterator de la classe Cadena
                return super.spliterator(); // crida el mètode spliterator de la superclasse Cadena
            }

            public void insert(char c, int n) { // sobreescriu el mètode insert de la classe Cadena
            }

            public void delete(int n) { // sobreescriu el mètode delete de la classe Cadena
            }

            public void deleteAll(char c) { // sobreescriu el mètode deleteAll de la classe Cadena
            }
        });
    }


    public void concat(char c) {
        // Defineix una nova cadena amb un array que conté un sol caràcter c.
        concat(new Cadena(new char[]{c}) {
            // Implementa els mètodes forEach i spliterator de l'interfície Iterable<Character>.
            public void forEach(Consumer<? super Character> action) {
                super.forEach(action);
            }

            public Spliterator<Character> spliterator() {
                return super.spliterator();
            }

            // Defineix els mètodes insert, delete, deleteAll de l'objecte Cadena.
            public void insert(char c, int n) {

            }

            public void delete(int n) {

            }

            public void deleteAll(char c) {

            }
        });
    }

    public static void insert(Cadena sx, char c, int n) {
        if (n < 0 || n > len) {
            return;
        }
        // Crea un nou array de caràcters i copia els primers n caràcters de cad a newCad.
        // Després afegeix el caràcter c i copia els caràcters restants de cad a newCad.
        char[] newCad = new char[len + 1];
        System.arraycopy(cad, 0, newCad, 0, n);
        newCad[n] = c;
        System.arraycopy(cad, n, newCad, n + 1, len - n);
        cad = newCad;
        len++;
    }

    public static void delete(Cadena sx, int n) {
        if (n < 0 || n >= len) {
            return;
        }
        // Crea un nou array de caràcters i copia els caràcters abans de l'índex n de cad a newCad.
        // Després copia els caràcters que hi ha després de l'índex n de cad a newCad.
        char[] newCad = new char[len - 1];
        System.arraycopy(cad, 0, newCad, 0, n);
        System.arraycopy(cad, n + 1, newCad, n, len - n - 1);
        cad = newCad;
        len--;
    }

    public static Cadena deleteAll(Cadena sx, char c) {
        // Compta el nombre de vegades que el caràcter c apareix a l'array de caràcters cad.
        int count = 0;
        for (int i = 0; i < len; i++) {
            if (cad[i] == c) {
                count++;
            }
        }
        // Crea un nou array de caràcters sense els caràcters c.
        char[] newCad = new char[len - count];
        int j = 0;
        for (int i = 0; i < len; i++) {
            if (cad[i] != c) {
                newCad[j] = cad[i];
                j++;
            }
        }
        // Actualitza l'array de caràcters cad amb el nou array i actualitza la longitud len.
        cad = newCad;
        len -= count;
        // Retorna l'objecte Cadena original sense els caràcters c.
        return sx;
    }


    // Aquest mètode permuta dos caràcters en una posició determinada de la cadena
    public void permuta(int x, int y) {
        if (x < 0 || x >= len || y < 0 || y >= len) {
            return;
        }
        char temp = cad[x];
        cad[x] = cad[y];
        cad[y] = temp;
    }

    // Aquest mètode esborra tots els caràcters de la cadena
    public void clear() {
        cad = new char[0];
        len = 0;
    }

    // Aquest mètode retorna un iterador per recórrer la cadena
    public Iterator<Character> iterator() {
        return new CadenaIterator();
    }

    private class CadenaIterator implements Iterator<Character> {
        private int currentIndex = 0;

        // Comprova si hi ha un següent caràcter a la cadena
        public boolean hasNext() {
            return currentIndex < len;
        }
        // Retorna el següent caràcter de la cadena i actualitza l'índex
        public Character next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            char currentChar = cad[currentIndex];
            currentIndex++;
            return currentChar;
        }

    }
}