import java.util.Iterator;
/**
 * ------------  Classe per provar les classes Cadena i Cadenas  -------------
 * Posar aquestes classes al package per defecte i lliurar un fitxer comprimit
 * amb les tres classes (les altres dues i aquesta)
 * @author  Jos� Javier FaroRodr�guez
*/
public class ProvaCadenes{
    public static void main(String[] args) {
        // Ens creem una llista de cadenes
        Cadenas grpCadenes = new Cadenas();
        // Generem deu valors aleatoris entre 0 i 999, els convertim en 
        // cadenes i els fiquem a la llista
        for (int n=0; n<10; n++)
            grpCadenes.add(new Cadena(Integer.toString((int)(Math.random()*1000))));
        // Afegim dos valors petits que no acostumen a sortir
        grpCadenes.add(new Cadena("9"));
        grpCadenes.add(new Cadena("92"));
        System.out.println("\n---------------- PROVA D'ORDENACI� DE CADENES --------------");
        // Escrivim la llista inicial
        System.out.println("Llista de partida (generada aleat�riament)");
        System.out.println(grpCadenes);
        // Ordenem alfab�ticament (ordre natural o per defecte)
        grpCadenes.sort();
        // Escrivim la llista ordenada alfab�ticament
        System.out.println("Llista ordenada alfab�ticament");
        System.out.println(grpCadenes);
        // Ordenem en ordre alfab�tic invers
        grpCadenes.sortInvers();
        System.out.println("Llista ordenada alfab�ticament a l'inversa");
        // L'escrivim ara en ordre alfab�tic invers
        System.out.println(grpCadenes);
        // Ordenem en ordre num�ri, de menor a major
        System.out.println("Llista ordenada num�ricament de menor a major");
        grpCadenes.sortNumeric();
        // L'escrivim ara en ordre num�ric de menor a major
        System.out.println(grpCadenes);
        System.out.println("Llista ordenada num�ricament de major a menor");
        grpCadenes.sortNumericInvers();
        // L'escrivim ara en ordre num�ric de major a menor
        System.out.println(grpCadenes);
        // ----------- Parte del codi per iterar sobre Cadenas  ------------
        System.out.println("\n-------------- PROVA DE L'ITERADOR SOBRE CADENES ------------");
        // Recorregut de Cadenas amb un bucle for-each
        System.out.println("Recorrem i escrivim l'objecte grpCadenes amb un bucle for-each");
        System.out.print("[");
        for (Cadena c:grpCadenes)
            System.out.print(c + ", ");
        System.out.println(" ]\n");
        System.out.println("Recorrem i escrivim l'objecte grpCadenes amb un iterador");
        Iterator <Cadena> it = grpCadenes.iterator();
        Cadena aux;     // Apuntador a objectes Cadena
        System.out.print("[");
        while (it.hasNext()){
            aux = it.next();
            System.out.print(aux + ", ");
            if (Integer.parseInt(aux.toString()) >= 100 &&
                Integer.parseInt(aux.toString()) <= 500)
                it.remove();
        }
        System.out.println(" ]\n");
        System.out.println("Objecte grpCadenes despr�s d'esborrar els valors entre 100 i 500");
        System.out.println(grpCadenes);
    }
}
