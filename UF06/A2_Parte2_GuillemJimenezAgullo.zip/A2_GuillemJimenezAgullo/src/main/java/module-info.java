module com.example.a2 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;
    requires java.desktop;

    opens com.example.a2 to javafx.fxml, javafx.graphics;
    exports com.example.a2;
}
