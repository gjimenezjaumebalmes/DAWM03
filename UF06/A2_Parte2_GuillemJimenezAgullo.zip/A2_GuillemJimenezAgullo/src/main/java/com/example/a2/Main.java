package com.example.a2;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main extends Application {

    // Declaración de variables
    private static final ObservableList<Treballador> treballadors = FXCollections.observableArrayList();

    // Declaración de constantes para la conexión a la base de datos
    private static final String DB_URL = "jdbc:mysql://vps-89148e22.vps.ovh.net:3306/jjfaro";
    private static final String USER = "jjfaro";
    private static final String PASSWORD = "keiL2lai";
    private static final String TABLE_NAME = "treballadors_41";

    /**
     * Mètode principal, recuperem informació de la BD mitjançant una classe de
     * persistència que hem anomenat PersisteBD
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);

    }

    @Override
    public void start(Stage primaryStage) {

        int numTreballadors;        // Nombre de treballadors de l'empresa
        Scanner sc = new Scanner(System.in);
        // Cadena que retorna les dades del treballador consultat
        int idtreballadors;             // Número identificador del treballador
        System.out.println("----- Recuperant treballadors des de la taula treballadors -----");
        // Creem l'objecte de la classe de persistància
        PersisteBD persi = new PersisteBD();
        // Recuperem les dades de la taula treballadors de la BD sobre una llista
        // d'objectes Treballador (compatible amb la taula), amb el segon mètods que
        // hem programat
        ArrayList<Treballador> treballadors = persi.getWorkersCall();
        // numTreballadors indica el nombre de treballadors inicial
        numTreballadors = Treballador.getNumTreballadors();
        // Indiquem el número de treballadors que hi havia a la BD de persistència
        System.out.println("Número de treballadors recuperats: " + numTreballadors);
        // Visualitzem aquests treballadors mitjançant el mètode toString() de la
        // classe Treballador
        System.out.println("ArrayList de treballadors recuperat:");
        for (int n = 0; n < numTreballadors; n++)
            System.out.println(treballadors.get(n));
        // Cridem al mètode addWorkers(treballadros) que afegirà 3 "operari" a la
        // llista treballadors
        // Insertar los nuevos trabajadores en la base de datos
        System.out.println("----- Afegint els tres nous treballadors a la llista -----");
        ArrayList<Treballador> nuevosTreballadors = new ArrayList<>();
        // Agregar los tres nuevos trabajadores al final de la lista
        nuevosTreballadors.add(new Treballador("Monica Lara Jimenez", "Operàri", "45217338", 25, "D"));
        nuevosTreballadors.add(new Treballador("David Fresquet Jimenez", "Treballador", "45222218", 30, "H"));
        nuevosTreballadors.add(new Treballador("Guillem Jimenez Agullo", "Treballador", "45217234", 28, "H"));

        // Imprimir los nuevos trabajadores agregados
        for (Treballador treballador : nuevosTreballadors) {
            System.out.println(treballador);
        }
        // Llamar al método addWorkers para insertar los nuevos trabajadores en la base de datos
        PersisteBD.addWorkers(nuevosTreballadors);
        // Visualitzem els treballadors de la llista després d'afegir els tres nous
        System.out.println("----- Desant tots els treballadors a la taula workers -----");
        // Crida al mètode per crear la taula on emmagatzemar els operaris
        if (persi.createTable())    // Es crea la taula workers
            System.out.println("S'ha creat la taula workers correctament");
        else
            System.out.println("No s'ha pogut crear la taula workers a la BD jjfaro");
        // Afegim els tres treballadors de la llista a la BD (taula workers)
        if (persi.storeWorkers())
            System.out.println("S'han desat tots els treballadors a la taula workers");
        else
            System.out.println("No s'han pogut  desar els treballadors a la taula workers");

        System.out.println("------- Consulta de recerca parametritzada per id -----");
        // Consultes a la taula treballadors per id del treballador (parametritzat)
        do {
            System.out.print("Introdueix el número identificador del treballador (0 - acaba):  ");
            idtreballadors = sc.nextInt();
            if (idtreballadors != 0) {
                persi.getWorkerDataById(idtreballadors);
                System.out.println("..........");
            }
        }
        while (idtreballadors != 0);
        System.out.println("Recerca per id finalitzada");
        // Consultem a la taula treballadors, per idtreballadors parametritzada i amb stores procedures
        System.out.println("----- Consulta de recerca per id amb Stored procedures parametritzats -----");
        StringBuilder sCall;        // Dades del treballador llegit en un StringBuilder
        do {
            System.out.print("Número identificador del treballador (0 - acaba):  ");
            idtreballadors = sc.nextInt();
            if (idtreballadors != 0) {
                sCall = persi.getDadesWorkerByIdCall(idtreballadors);
                if (sCall != null)
                    System.out.println(sCall);
                else
                    System.out.println("No hi ha cap treballador amb aquest identificador a la BD");
            }
        }
        while (idtreballadors != 0);
        System.out.println("Recerca per id amb Stored Procedures finalitzada");
        // Comenteu aquestes línies si no heu fet aquesta part
        System.out.println("\n----- Consulta parametritzada amb dos ? (Opcional) -----");
        System.out.println("Treballadors amb càrrec: 'treballador' i Homes a l'empresa:");
        System.out.println(persi.getDadesCarrecSexeCall("Treballador", 'H'));
        System.out.println("Treballadores amb càrrec: 'treballador' i Dones a l'empresa:");
        System.out.println(persi.getDadesCarrecSexeCall("Treballador", 'D'));

    }


    public static class PersisteBD {
        private static Connection conn;
        private final String url;
        private final String user;
        private final String password;
        private final String tableName;

        public PersisteBD() {
            this.url = DB_URL;
            this.user = USER;
            this.password = PASSWORD;
            this.tableName = TABLE_NAME;
            conn = connectdb();
        }

        private Connection connectdb() {
            try {
                return DriverManager.getConnection(url, user, password);
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
        }

        private void getWorkerDataById(int idtreballadors) {
            com.example.a2.getWorkerDataById.getWorkerDataById(idtreballadors);
        }

        public StringBuilder getDadesWorkerByIdCall(int idtreballadors) {
            StringBuilder sCall = new StringBuilder();
            try {
                // Llamar al stored procedure para obtener los datos del trabajador por su ID
                String query = "{CALL getDadesWorkerById_41(?)}";
                CallableStatement stmt = conn.prepareCall(query);
                stmt.setInt(1, idtreballadors);
                ResultSet rs = stmt.executeQuery();

                // Construir el StringBuilder con los datos obtenidos
                if (rs.next()) {
                    sCall.append("ID: ").append(rs.getInt("idtreballadors")).append("\n");
                    sCall.append("Nom: ").append(rs.getString("nom")).append("\n");
                    sCall.append("Carrec: ").append(rs.getString("carrec")).append("\n");
                }

                rs.close();
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return sCall;
        }

        public boolean createTable() {
            try {
                Statement stmt = conn.createStatement();

                // Crear la tabla en la base de datos si no existe
                String query = "CREATE TABLE IF NOT EXISTS " + tableName + " (" +
                        "idtreballadors INT PRIMARY KEY AUTO_INCREMENT, " +
                        "nom VARCHAR(50) NOT NULL, " +
                        "carrec VARCHAR(50) NOT NULL," +
                        "dni VARCHAR(9) NOT NULL," +
                        "edat INT NOT NULL," +
                        "sexe VARCHAR(1) NOT NULL" +
                        ")";
                stmt.executeUpdate(query);

                stmt.close();
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        private static void addWorkers(ArrayList<Treballador> nuevosTreballadors) {
            try {
                String query = "INSERT INTO " + TABLE_NAME + " (nom, carrec, dni, edat, sexe) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement statement = conn.prepareStatement(query);

                for (Treballador treballador : nuevosTreballadors) {
                    statement.setString(1, treballador.nom);
                    statement.setString(2, treballador.carrec);
                    statement.setString(3, treballador.dni);
                    statement.setInt(4, treballador.edat);
                    statement.setString(5, treballador.sexe);
                    statement.executeUpdate();
                }

                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        private boolean storeWorkers() {
            for (Treballador treballador : Main.treballadors) {
                // Verificar si el identificador ya está en uso
                boolean idExists = checkIdExists(treballador.getIdtreballadors());

                if (!idExists) {
                    // Consultar el trabajador en la base de datos
                    String sql = "SELECT * FROM " + TABLE_NAME + " WHERE idtreballadors = ?";

                    try (PreparedStatement statement = conn.prepareStatement(sql)) {
                        statement.setInt(1, treballador.getIdtreballadors());

                        ResultSet resultSet = statement.executeQuery();

                        // Verificar si hay algún resultado
                        if (resultSet.next()) {
                            System.out.println("El identificador " + treballador.getIdtreballadors() + " ya está en uso.");
                        } else {
                            // Insertar el trabajador en la base de datos
//                            Main.treballadors.add(treballador);
                            System.out.println("Trabajador almacenado correctamente.");
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    System.out.println("El identificador " + treballador.getIdtreballadors() + " ya está en uso.");
                }
            }
            return true;
        }

        private boolean checkIdExists(int id) {
            String sql = "SELECT COUNT(*) FROM treballadors_41 WHERE idtreballadors = ?";

            try (PreparedStatement statement = conn.prepareStatement(sql)) {
                statement.setInt(1, id);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        return count > 0;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return false;
        }


        public ArrayList<Treballador> getWorkersCall() {
            ArrayList<Treballador> treballadors = new ArrayList<>();
            try {
                // Llamar al stored procedure para obtener los datos de los trabajadores
                String query = "{CALL getWorkers_41()}";
                CallableStatement stmt = conn.prepareCall(query);
                ResultSet rs = stmt.executeQuery();

                // Obtener los datos y agregarlos a la lista de treballadors
                while (rs.next()) {
                    String nom = rs.getString("nom");
                    String carrec = rs.getString("carrec");
                    String dni = rs.getString("dni");
                    int edat = rs.getInt("edat");
                    String sexe = rs.getString("sexe");
                    Treballador treballador = new Treballador(nom, carrec, dni, edat, sexe);
                    treballadors.add(treballador);
                }

                rs.close();
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return treballadors;
        }


        public StringBuilder getDadesCarrecSexeCall(String carrec, char sexe) {
            StringBuilder sCall = new StringBuilder();
            try {
                // Llamar al stored procedure para obtener los datos de los trabajadores según el carrec y sexe
                String query = "{CALL getDadesCarrecSexe_41(?, ?)}";
                CallableStatement stmt = conn.prepareCall(query);
                stmt.setString(1, carrec);
                stmt.setString(2, String.valueOf(sexe));
                ResultSet rs = stmt.executeQuery();

                // Construir el StringBuilder con los datos obtenidos
                while (rs.next()) {
                    sCall.append("ID: ").append(rs.getInt("idtreballadors")).append("\n");
                    sCall.append("Nom: ").append(rs.getString("nom")).append("\n");
                    sCall.append("Carrec: ").append(rs.getString("carrec")).append("\n");
                    sCall.append("\n");
                }

                rs.close();
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return sCall;
        }

    }
}
