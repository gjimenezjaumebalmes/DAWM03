package com.example.a2;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

class getDadesCarrecSexe {

    public void getDadesCarrecSexe(String carrec, char sexe, Connection connection) {
        try {
            String query = "{CALL getDadesCarrecSexe_41(?, ?)}";
            CallableStatement statement = connection.prepareCall(query);
            statement.setString(1, carrec);
            statement.setString(2, String.valueOf(sexe));

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int count = 0;
                StringBuilder workersList = new StringBuilder();

                do {
                    int id = resultSet.getInt("idtreballadors");
                    String nom = resultSet.getString("nom");
                    String sex = resultSet.getString("sexe");

                    count++;
                    workersList.append("ID: ").append(id).append(", Nom: ").append(nom).append(", Sexe: ").append(sex).append("\n");
                } while (resultSet.next());

                System.out.println("Nombre de treballadors amb càrrec Treballador : " + count);

                if (workersList.length() > 0) {
                    System.out.println(workersList.toString());
                }
            } else {
                System.out.println("No s'han trobat treballadors amb el càrrec especificat.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
