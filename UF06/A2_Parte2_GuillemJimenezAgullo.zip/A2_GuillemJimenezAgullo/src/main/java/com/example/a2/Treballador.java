package com.example.a2;

public class Treballador {

    private static int numTreballadors = 0;
    private int idtreballadors = 0;
    public String nom;
    public String carrec;
    public String dni;
    public int edat;
    public String sexe;

    public Treballador(String nom, String carrec, String dni, int edat, String sexe) {
        this.idtreballadors = idtreballadors;
        this.nom = nom;
        this.carrec = carrec;
        this.dni = dni;
        this.edat = edat;
        this.sexe = sexe;
        numTreballadors++; // Incrementa el contador de trabajadores al crear una instancia
    }



    public static int getNumTreballadors() {
        return numTreballadors;
    }

    public int getIdtreballadors() {
        return idtreballadors;
    }

    public String getNom() {
        return nom;
    }

    public String getCarrec() {
        return carrec;
    }

    public String getDni() {
        return dni;
    }

    public int getEdat() {
        return edat;
    }

    public String getSexe() {
        return sexe;
    }


    @Override
    public String toString() {
        return "Treballador{" +
                "id=" + idtreballadors +
                ", nom='" + nom + '\'' +
                ", carrec='" + carrec + '\'' +
                ", dni='" + dni + '\'' +
                ", edat=" + edat +
                ", sexe=" + sexe +
                '}';
    }


    public void setIdtreballadors(int idtreballadors) {
        this.idtreballadors = idtreballadors;
    }
}
