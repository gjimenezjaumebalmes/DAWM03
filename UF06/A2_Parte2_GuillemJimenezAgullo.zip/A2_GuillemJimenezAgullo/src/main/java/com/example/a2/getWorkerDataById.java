package com.example.a2;

import java.sql.*;

public class getWorkerDataById {
    // Declaración de constantes para la conexión a la base de datos
    private static final String DB_URL = "jdbc:mysql://vps-89148e22.vps.ovh.net:3306/jjfaro";
    private static final String USER = "jjfaro";
    private static final String PASSWORD = "keiL2lai";

    public static void getWorkerDataById(int workerId) {
        try {
            // Establecer la conexión con la base de datos
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);

            // Llamar al procedimiento almacenado
            CallableStatement stmt = conn.prepareCall("{CALL getDadesWorkerById_41(?)}");
            stmt.setInt(1, workerId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                // Obtén los valores de la consulta
                int idtreballadors = rs.getInt("idtreballadors");
                String nom = rs.getString("nom");
                String cargo = rs.getString("carrec");


                // Realiza las operaciones necesarias con los datos obtenidos
                // ...
                System.out.println("ID: " + idtreballadors);
                System.out.println("Nom: " + nom);
                System.out.println("Carrec: " + cargo);

            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}