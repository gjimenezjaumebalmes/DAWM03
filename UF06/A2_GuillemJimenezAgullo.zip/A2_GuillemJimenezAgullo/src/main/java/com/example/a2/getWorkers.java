package com.example.a2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.ObservableList;

public class getWorkers {
    private Connection connection;

    // Declaración de constantes para la conexión a la base de datos
    private static final String TABLE_NAME = "treballadors_41";

    public getWorkers() {
        this.connection = connection;
    }

    public void getWorkers(ObservableList<Treballador> treballadors) {
        try {
            // Recuperar treballadors de la tabla treballadors_41
            String query = "SELECT * FROM " + TABLE_NAME;
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("idtreballadors");
                String nom = resultSet.getString("nom");
                String carrec = resultSet.getString("carrec");
                String dni = resultSet.getString("dni");
                int edat = resultSet.getInt("edat");
                String sexe = resultSet.getString("sexe");

                // Crear objeto Treballador y agregarlo a la lista
                Treballador treballador = new Treballador(id, nom, carrec, dni, edat, sexe);
                treballadors.add(treballador);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
