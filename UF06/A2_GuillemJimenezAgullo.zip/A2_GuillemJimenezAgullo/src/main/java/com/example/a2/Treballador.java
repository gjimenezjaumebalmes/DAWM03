package com.example.a2;

public class Treballador {
    private int id;
    private String nom;
    private String carrec;
    private String dni;
    private int edat;
    private String sexe;

    public Treballador(int id, String nom, String carrec, String dni, int edat, String sexe) {
        this.id = id;
        this.nom = nom;
        this.carrec = carrec;
        this.dni = dni;
        this.edat = edat;
        this.sexe = sexe;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getCarrec() {
        return carrec;
    }

    public String getDni() {
        return dni;
    }

    public int getEdat() {
        return edat;
    }

    public String getSexe() {
        return sexe;
    }

    @Override
    public String toString() {
        return "Treballador{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", carrec='" + carrec + '\'' +
                ", dni='" + dni + '\'' +
                ", edat=" + edat +
                ", sexe=" + sexe +
                '}';
    }
}
