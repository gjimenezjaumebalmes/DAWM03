package com.example.a2;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class countWorkersBySex {
    private Connection connection;

    public countWorkersBySex(Connection connection) {
        this.connection = connection;
    }

    public void getDadesCarrecSexe(String tableName) {
        try {
            String query = "{CALL getDadesCarrecSexe_41(?)}";
            CallableStatement statement = connection.prepareCall(query);
            statement.setString(1, tableName);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int count = 0;
                StringBuilder workersList = new StringBuilder();

                do {
                    int id = resultSet.getInt("idtreballadors");
                    String nom = resultSet.getString("nom");
                    String sex = resultSet.getString("sexe");

                    count++;
                    workersList.append("ID: ").append(id).append(", Nom: ").append(nom).append(", Sexe: ").append(sex).append("\n");
                } while (resultSet.next());

                System.out.println("Nombre de treballadors amb càrrec '" + tableName + "': " + count);

                if (workersList.length() > 0) {
                    System.out.println(workersList.toString());
                }
            } else {
                System.out.println("No s'han trobat treballadors amb el càrrec especificat.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
