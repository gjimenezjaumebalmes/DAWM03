package com.example.a2;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;

public class Main extends Application {
    private ObservableList<Treballador> treballadors = FXCollections.observableArrayList();
    private TextField idTextField;
    private Label resultLabel;
    private Connection connection;
    private countWorkersBySex countWorkersBySex;

    // Declaración de constantes para la conexión a la base de datos
    private static final String DB_URL = "jdbc:mysql://vps-89148e22.vps.ovh.net:3306/jjfaro";
    private static final String SERVER = "vps-89148e22.vps.ovh.net:3306";
    private static final String USER = "jjfaro";
    private static final String PASSWORD = "keiL2lai";
    private static final String DB = "jjfaro";
    private static final String TABLE_NAME = "treballadors_41";

    @Override
    public void start(Stage primaryStage) {
        ListView<Treballador> listView = new ListView<>(treballadors);
        listView.setPrefWidth(400);

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        Label idLabel = new Label("Número identificador del treballador:");
        idTextField = new TextField();
        Button searchButton = new Button("Buscar");
        Button countMaleButton = new Button("Listar trabajadores con cargo treballadors y Hombres");
        Button countFemaleButton = new Button("Listar trabajadores con cargo treballadors y Mujeres");
        resultLabel = new Label();

        searchButton.setOnAction(e -> searchWorker());
        countMaleButton.setOnAction(e -> countWorkersBySex.getDadesCarrecSexe("H"));
        countFemaleButton.setOnAction(e -> countWorkersBySex.getDadesCarrecSexe("D"));


        root.getChildren().addAll(listView, idLabel, idTextField, searchButton, countMaleButton, countFemaleButton, resultLabel);

        primaryStage.setScene(new Scene(root, 400, 400));
        primaryStage.setTitle("Treballadors");
        primaryStage.show();

        // Conectar a la base de datos
        connectToDatabase(SERVER, USER, PASSWORD);

        // Inicializar la instancia de CountWorkersBySex
        countWorkersBySex = new countWorkersBySex(connection);

        // Cargar los treballadors desde la base de datos
        getWorkers();
    }

    private void connectToDatabase(String serverName, String user, String password) {
        try {
            // Cargamos el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecemos la conexión a la base de datos
            String url = "jdbc:mysql://" + SERVER + "/" + DB;
            connection = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void getWorkers() {
        // Utilizar la clase GetWorkers del archivo getWorkers.java
        getWorkers getWorkers = new getWorkers();
        getWorkers.getWorkers(treballadors);
    }


    private void searchWorker() {
        int id = Integer.parseInt(idTextField.getText());
        getWorkerDataById getWorkerDataById = new getWorkerDataById();
        getWorkerDataById.getWorkerDataById(id);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
